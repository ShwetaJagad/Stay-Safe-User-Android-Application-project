<?php
if (isset($_POST['submit'])) {
$fields = array(
    "variables_values" => "5599",
    "route" => "otp",
    "numbers" => "9687161302",
);

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_SSL_VERIFYHOST => 0,
  CURLOPT_SSL_VERIFYPEER => 0,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => json_encode($fields),
  CURLOPT_HTTPHEADER => array(
    "authorization: Vlt81Bn2l3fOz1ztup3XEPq6kd9By36gmJPMLSmIJqDQVxtGUjcA8S0If2hC",
    "accept: */*",
    "cache-control: no-cache",
    "content-type: application/json"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo $response;
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
<style>
     body {
        background-color: white;
      }
      .container{
        height: 47px;
        position: absolute;
        top: 0px;
        left: 0px;
        width: 1280px;
        font-size: 34px;
        background-color:   rgb(241, 235, 235);
        text-align: center;
        color: black;
      }
      .back img {
        top: -22px;
        position: absolute;
        left: 8px;
        width: 39px;
        height: 39px;
      }
    img{
        display:block;
        margin:2% auto;
        width:20%
    }
    
    .con{
        border: 2px solid black;
        /* margin:3% 50% 0% 35% ; */
        width:400px;
        height:33px;
        padding:1px 1px 1px 1px;
        border-radius: 5px;
        background-color: rgb(241, 235, 235);
        position: absolute;
    left: 28px;
    top: -6px;
    }
    .con h6{
        text-align: center;
        font-weight: bold;
        margin:6px 2px 1px 1px;
        font-size: 25px;
    }
    .c{
        border: 2px solid black;
        /* margin:0% 50% 0% 35% ; */
        width:400px;
        height: 150px;
        border-radius: 5px;
        position: absolute;
    left: 29px;
    top: 39px;
    }
    .c textarea{
        font-size: large;
        background-color: rgb(241, 235, 235);
    }
    .btn{
        font-family: Arial, Helvetica, sans-serif;
        /* margin: 3% 45% 0% 45%; */
        background-color: rgb(241, 235, 235);
        padding: 15px 3px;
        border: 2px solid black;
        border-radius: 10px;
        font-size: 20px;
        cursor: pointer;
        font-weight: bold;
        width: 144px;
    height: 48px;
    position: absolute;
    top: 201px;
    left: 148px;
    }
    .mainbox{
        position: absolute;
            top: 111px;
            left: 408px;
    }
</style>
<script>
    function showMessage() {
        alert("alert sent succesfully..");
    }
</script>
</head>
<body>
  
    <div class="container">
        <div class="back">
          <a href="homepage.html"><img src="img/back.png" alt="Error" /></a>
        </div>
       Send Alert
      </div>
      <div class="mainbox">

          <div class="con">
              <h6>Alert!&nbsp&nbsp Alert! &nbsp&nbspAlert!</h6>
              <form>
            </form>
        </div>
        <div class="c">
            <form>
                <textarea name="m" cols="50" rows="50" style="height:144px; width:394px;" 
                placeholder="
                some goons chasing me..
                I am in trouble ...
                I need help...
                Pls help me.."></textarea></form>
            </div>
            <form>
                <button class="btn" onClick="showMessage()">Send Alert</button>
            </form>
        </div>
        </body>
</html>